# Hubframe Shifter

Free Codex custom pet package.

## Included Files

- `pet.json`
- `spritesheet.webp`
- `validation.json`
- `contact-sheet.png`
- `review.json`
- `pet-calling.json`
- `LICENSE-ja.md`
- `license-template.json`

## Install

1. Close Codex.
2. Copy this whole folder, `hubframe-shifter`, into your Codex pets folder.
   - Windows: `%USERPROFILE%\.codex\pets\`
   - macOS/Linux: `~/.codex/pets/`
3. Confirm the final path looks like:
   - `hubframe-shifter/pet.json`
   - `hubframe-shifter/spritesheet.webp`
4. Restart Codex and choose `Hubframe Shifter` from custom pets.

## Registered Pet Calling

This package includes `pet-calling.json` for launchers or media that support a registered pets list.

1. Import this package into the app or launcher.
2. Confirm the illustration preview and display name.
3. Save the call name as `Hubframe Shifter` and aliases as needed.
4. Type `@Hubframe Shifter`, `Hubframe Shifterを呼んで`, or `配線メカにして` to switch the active pet.
5. If another pet already uses the same call name, rename this one before saving.

## Character Notes

Hubframe Shifter turns a desk dock, USB hub, and cable organizer into a compact tech pet.
Its directional movement uses a side-facing flying hero pose rather than walking, so the pet reads as a small transformable robot moving across the screen.

## Validation

The included `spritesheet.webp` was validated as a Codex pet atlas:

- Size: `1536x1872`
- Cell size: `192x208`
- Rows: `9`
- Columns: `8`
- Format: `WEBP`
- Mode: `RGBA`
- Transparent RGB residue: `0`

## License Summary

Personal and commercial use are allowed for your own projects.
Redistribution, resale as-is, claiming official OpenAI/Codex endorsement, or training datasets are not included.
Get the latest version from the official distribution page whenever possible.

This asset is an independent custom pet pack and is not an official OpenAI product.
It uses abstract dock, cable, and robot motifs only; it does not include official USB, hardware vendor, OpenAI, Codex, GitHub, or plugin service logos.
