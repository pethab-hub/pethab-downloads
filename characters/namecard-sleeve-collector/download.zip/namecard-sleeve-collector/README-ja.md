# PETHAB-DL-015: Namecard Sleeve Collector

<!-- pethab-package-number -->
## Package number

- Package No: `PETHAB-DL-015`
- Package title: `PETHAB-DL-015: Namecard Sleeve Collector`
- X/social reference: `PETHAB-DL-015` / `#PETHABDL015`

Use this number when posting, cataloging, or matching model/gallery images to the download package.
<!-- /pethab-package-number -->
Free Codex custom pet package.

## Included files

- `pet.json`
- `spritesheet.webp`
- `validation.json`
- `contact-sheet.png`
- `pet-calling.json`
- `LICENSE-ja.md`
- `license-template.json`

## Install

1. Close Codex.
2. Copy this whole folder, `namecard-sleeve-collector`, into your Codex pets folder.
   - Windows: `%USERPROFILE%\.codex\pets\`
   - macOS/Linux: `~/.codex/pets/`
3. Confirm the final path looks like:
   - `namecard-sleeve-collector/pet.json`
   - `namecard-sleeve-collector/spritesheet.webp`
4. Restart Codex and choose `Namecard Sleeve Collector` from custom pets.

## Registered pet calling

This package includes `pet-calling.json` for launchers or media that support a registered pets list.

1. Import this package into the app or launcher.
2. Confirm the illustration preview and display name.
3. Save the call name as `名刺スリーブ` and aliases as needed.
4. Type `@名刺スリーブ`, `名刺スリーブを呼んで`, or `Namecard Sleeve Collectorにして` to switch the active pet.
5. If another pet already uses the same call name, rename this one before saving.

## Validation

The included `spritesheet.webp` was validated as a Codex pet atlas:

- Size: `1536x1872`
- Cell size: `192x208`
- Rows: `9`
- Columns: `8`
- Format: `WEBP`
- Mode: `RGBA`
- Transparent RGB residue: `0`

## License summary

Personal and commercial use are allowed for your own projects.
Redistribution, resale as-is, claiming official OpenAI/Codex endorsement, or training datasets are not included.
Get the latest version from the official distribution page whenever possible.

This asset is an independent custom pet pack and is not an official OpenAI product.
