# Voice Memo Shell Listener

Free Codex custom pet package.

## Included Files

- `pet.json`
- `spritesheet.webp`
- `validation.json`
- `contact-sheet.png`
- `review.json`
- `pet-calling.json`
- `LICENSE-ja.md`
- `license-template.json`

## Install

1. Close Codex.
2. Copy this whole folder, `voice-memo-shell-listener`, into your Codex pets folder.
   - Windows: `%USERPROFILE%\.codex\pets\`
   - macOS/Linux: `~/.codex/pets/`
3. Confirm the final path looks like:
   - `voice-memo-shell-listener/pet.json`
   - `voice-memo-shell-listener/spritesheet.webp`
4. Restart Codex and choose `Voice Memo Shell Listener` from custom pets.

## Registered Pet Calling

This package includes `pet-calling.json` for launchers or media that support a registered pets list.

1. Import this package into the app or launcher.
2. Confirm the illustration preview and display name.
3. Save the call name as `Voice Memo Shell Listener` and aliases as needed.
4. Type `@Voice Memo Shell Listener`, `貝メモにして`, or `音声メモpetに切り替えて` to switch the active pet.
5. If another pet already uses the same call name, rename this one before saving.

## Character Notes

Voice Memo Shell Listener turns voice memo work into a small shell-listening ritual.
It receives an imagined voice into a shell, closes the shell to save it, presents it for approval, and holds it near the ear to review playback.
The pet avoids waveform marks, music notes, microphone logos, app UI, and readable text.

## Validation

The included `spritesheet.webp` was validated as a Codex pet atlas:

- Size: `1536x1872`
- Cell size: `192x208`
- Rows: `9`
- Columns: `8`
- Format: `WEBP`
- Mode: `RGBA`
- Transparent RGB residue: `0`

## License Summary

Personal and commercial use are allowed for your own projects.
Redistribution, resale as-is, claiming official OpenAI/Codex endorsement, or training datasets are not included.
Get the latest version from the official distribution page whenever possible.

This asset is an independent custom pet pack and is not an official OpenAI product.
It uses abstract shell, listening, and memo-saving motifs only; it does not include official recorder, microphone, transcription, app, OpenAI, Codex, or plugin service logos.
