# Cable Cat Nester

Free-member Desk Muse custom pet package.

## Character concept

Cable Cat Nester is a small cable-tidy mascot for desk setup content. Her core personality is `巣に戻す`: she curls up inside a cable nest when idle, untangles a small cord loop, tucks it into an abstract pouch, and checks that the desk is calm again.

The error motion uses the user's stronger idea: the cord wraps around the body in a readable, comic way. The failed row uses closed slanted crying eyes and attached tears so the state reads as `絡まって泣きそうだけど戻れる`, not a harsh failure.

## Included files

- `pet.json`
- `spritesheet.webp`
- `validation.json`
- `review.json`
- `contact-sheet.png`
- `previews/*.gif`
- `pet-calling.json`
- `LICENSE-ja.md`
- `license-template.json`

## Install

1. Close Codex.
2. Copy this whole folder, `cable-cat-nester`, into your Codex pets folder.
   - Windows: `%USERPROFILE%\.codex\pets\`
   - macOS/Linux: `~/.codex/pets/`
3. Confirm the final path looks like:
   - `cable-cat-nester/pet.json`
   - `cable-cat-nester/spritesheet.webp`
4. Restart Codex and choose `Cable Cat Nester` from custom pets.

## Registered pet calling

This package includes `pet-calling.json` for launchers or media that support a registered pets list.

1. Import this package into the app or launcher.
2. Confirm the illustration preview and display name.
3. Save the call name as `ケーブル猫` and aliases as needed.
4. Type `@ケーブル猫`, `ケーブル猫を呼んで`, or `Cable Cat Nesterにして` to switch the active pet.
5. If another pet already uses the same call name, rename this one before saving.

## Signature motions

- `idle`: curled-up sleeping in a cable nest with a small attached `Zzz` tag.
- `running`: untangle, tuck into the pouch, then confirm the loop is stored.
- `review`: looks into the abstract pouch window and nods.
- `waiting`: opens the pouch and waits for the user's next action.
- `failed`: cord/code-like cable wraps around the body; closed slanted crying eyes and attached tears show a bigger overreaction before recovery.
- `waving`: one paw greets while the other keeps the cable and pouch steady.

## Validation

The included `spritesheet.webp` was validated as a Codex pet atlas:

- Size: `1536x1872`
- Cell size: `192x208`
- Rows: `9`
- Columns: `8`
- Format: `WEBP`
- Mode: `RGBA`
- Transparent RGB residue: `0`
- Validation errors: `0`
- Validation warnings: `0`

## License summary

Personal and commercial use are allowed for your own projects.
Redistribution, resale as-is, claiming official OpenAI/Codex endorsement, or training datasets are not included.
Get the latest version from the official distribution page whenever possible.

This asset is an independent custom pet pack and is not an official OpenAI product.
