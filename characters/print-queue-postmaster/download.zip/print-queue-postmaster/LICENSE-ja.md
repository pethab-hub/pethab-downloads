# Print Queue Postmaster License Terms

This is a short practical license for the free digital asset.

## Allowed

- Personal use.
- Commercial use inside your own projects, apps, videos, streams, internal tools, and client work.
- Minor edits needed to display the pet correctly in your own environment.
- Showing the pet in screenshots, videos, streams, documentation, and promotional material for your own project.

## Not allowed

- Reselling, redistributing, sublicensing, sharing, uploading, or giving away the asset files as-is.
- Selling or distributing a modified version that is substantially the same asset.
- Including the asset files in a template, marketplace item, starter kit, dataset, stock bundle, or asset pack for others to extract.
- Claiming this is an official OpenAI or Codex asset, or implying endorsement by OpenAI.
- Using the files as training data, model fine-tuning data, or an image-generation dataset.
- Registering the character, sprite, or package as your own trademark or exclusive IP.

## User responsibility

Please keep the original ZIP structure and direct others to the official distribution page instead of redistributing the files.

## Product identity

- Product ID: `print-queue-postmaster`
- Display name: `Print Queue Postmaster`
- Files: `pet.json`, `spritesheet.webp`

This independent custom pet asset is compatible with Codex custom pet loading, but it is not an official OpenAI product.
