# Office Orbit Sister

Free-member Desk Muse custom pet package.

## Character concept

Office Orbit Sister is a calm office-support muse. Her core personality is `整える`: she clicks the mouse-shaped hair accessory to start work, confirms requests with an open-palm pose, and reviews output with a quiet nod.

## Included files

- `pet.json`
- `spritesheet.webp`
- `validation.json`
- `review.json`
- `contact-sheet.png`
- `previews/*.gif`
- `pet-calling.json`
- `LICENSE-ja.md`
- `license-template.json`

## Install

1. Close Codex.
2. Copy this whole folder, `office-orbit-sister`, into your Codex pets folder.
   - Windows: `%USERPROFILE%\.codex\pets\`
   - macOS/Linux: `~/.codex/pets/`
3. Confirm the final path looks like:
   - `office-orbit-sister/pet.json`
   - `office-orbit-sister/spritesheet.webp`
4. Restart Codex and choose `Office Orbit Sister` from custom pets.

## Signature motions

- `idle`: posture reset and calm breathing.
- `running`: head-click processing on the mouse-shaped hair accessory.
- `review`: focused confirmation and nod.
- `waiting`: open-palm approval request.
- `waving`: reserved greeting.

## Registered pet calling

This package includes `pet-calling.json` for launchers or media that support a registered pets list.

1. Import this package into the app or launcher.
2. Confirm the illustration preview and display name.
3. Save the call name as `オービット姉さん` and aliases as needed.
4. Type `@オービット姉さん`, `整え姉さんを呼んで`, or `Office Orbit Sisterにして` to switch the active pet.
5. If another pet already uses the same call name, rename this one before saving.

## Validation

The included `spritesheet.webp` was validated as a Codex pet atlas:

- Size: `1536x1872`
- Cell size: `192x208`
- Rows: `9`
- Columns: `8`
- Format: `WEBP`
- Mode: `RGBA`
- Transparent RGB residue: `0`
- Validation errors: `0`
- Validation warnings: `0`

## License summary

Personal and commercial use are allowed for your own projects.
Redistribution, resale as-is, claiming official OpenAI/Codex endorsement, or training datasets are not included.
Get the latest version from the official distribution page whenever possible.

This asset is an independent custom pet pack and is not an official OpenAI product.
