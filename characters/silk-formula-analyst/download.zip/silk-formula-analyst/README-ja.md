# PETHAB-DL-021: Silk Formula Analyst

<!-- pethab-package-number -->
## Package number

- Package No: `PETHAB-DL-021`
- Package title: `PETHAB-DL-021: Silk Formula Analyst`
- X/social reference: `PETHAB-DL-021` / `#PETHABDL021`

Use this number when posting, cataloging, or matching model/gallery images to the download package.
<!-- /pethab-package-number -->
Free Codex custom pet package.

## Included files

- `pet.json`
- `spritesheet.webp`
- `validation.json`
- `contact-sheet.png`
- `pet-calling.json`
- `LICENSE-ja.md`
- `license-template.json`

## Install

1. Close Codex.
2. Copy this whole folder, `silk-formula-analyst`, into your Codex pets folder.
   - Windows: `%USERPROFILE%\.codex\pets\`
   - macOS/Linux: `~/.codex/pets/`
3. Confirm the final path looks like:
   - `silk-formula-analyst/pet.json`
   - `silk-formula-analyst/spritesheet.webp`
4. Restart Codex and choose `Silk Formula Analyst` from custom pets.

## Registered pet calling

This package includes `pet-calling.json` for launchers or media that support a registered pets list.

1. Import this package into the app or launcher.
2. Confirm the illustration preview and display name.
3. Save the call name as `Silk Analyst` and aliases as needed.
4. Type `@Silk Analyst`, `Silk Analystを呼んで`, or `Silk Formula Analystにして` to switch the active pet.
5. If another pet already uses the same call name, rename this one before saving.

## Validation

The included `spritesheet.webp` was validated as a Codex pet atlas:

- Size: `1536x1872`
- Cell size: `192x208`
- Rows: `9`
- Columns: `8`
- Format: `WEBP`
- Mode: `RGBA`
- Transparent RGB residue: `0`

## License summary

Personal and commercial use are allowed for your own projects.
Redistribution, resale as-is, claiming official OpenAI/Codex endorsement, or training datasets are not included.
Get the latest version from the official distribution page whenever possible.

This asset is an independent custom pet pack and is not an official OpenAI product.
